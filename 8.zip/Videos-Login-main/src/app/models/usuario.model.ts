

export class UsuarioModel {

  email: string;
  password: string;
  nombre: string;

  constructor() {
    this.email = ''; // Inicializar la propiedad "email" con un valor predeterminado
    this.password = ''; // Inicializar la propiedad "password" con un valor predeterminado
    this.nombre = ''; // Inicializar la propiedad "nombre" con un valor predeterminado
  }





}
